I downloaded from https://fred.publichealth.pitt.edu/syn_pops.


